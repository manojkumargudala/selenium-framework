package com.sheild.testngdataprovider;

public interface DataReader {

}
