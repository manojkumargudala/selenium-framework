package com.sheild.utils;

public interface ReadPropertyData {
  public String readProperty(String key);

  public Boolean isRunningDebug();

  public Boolean isCodeChecksEnabled();
}
