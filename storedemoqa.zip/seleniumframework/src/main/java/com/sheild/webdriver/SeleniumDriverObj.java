package com.sheild.webdriver;

import org.openqa.selenium.WebDriver;

public interface SeleniumDriverObj {
  public WebDriver getDriver(String browerName, Boolean checkCodes);
}
