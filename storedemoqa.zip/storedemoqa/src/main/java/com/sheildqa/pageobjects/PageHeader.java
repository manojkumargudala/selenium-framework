package com.sheildqa.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Reporter;

import com.sheild.utils.BaseFrameWorkInitializer;

public class PageHeader {
	WebDriver driver;
	Wait<WebDriver> wait;
	@FindBy(xpath = "//em[@class='fa fa-navicon']")
	WebElement hamburger;
	@FindBy(xpath = "//input[@class='form-control text-field PIN--input ng-pristine ng-valid ng-empty ng-touched']")
	WebElement changeuserinput;
	@FindBy(xpath = "//input[@ng-model='testCorpId']")
	WebElement changeuserinput11;
	@FindBy(xpath = "//button[@id='case-go-button']")
	WebElement goButton;

	public PageHeader() {
		this.driver = BaseFrameWorkInitializer.getInstance().getDriver();
		this.wait = BaseFrameWorkInitializer.getInstance().getWebDriverWait();
	}

	public void hamBurger() throws InterruptedException {
		wait.until(ExpectedConditions.elementToBeClickable(hamburger));
		hamburger.click();
		Thread.sleep(3000);
		Reporter.log("hamburger clicked");
		wait.until(ExpectedConditions.visibilityOf(changeuserinput));
		changeuserinput.sendKeys("a024183");
		Reporter.log("input enterd");
		wait.until(ExpectedConditions.elementToBeClickable(goButton));
		goButton.click();
		Reporter.log("Verified Go button");
	}
}
