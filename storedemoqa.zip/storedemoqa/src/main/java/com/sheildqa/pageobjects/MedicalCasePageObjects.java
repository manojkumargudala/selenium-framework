package com.sheildqa.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MedicalCasePageObjects extends PageFooter {
	@FindBy(xpath = "//input[@ng-model='caseDetails.origin.caseName']")
	WebElement classnameinput;
	@FindBy(xpath = "//i[@class='fa fa-calendar']")
	WebElement occureddate;
	@FindBy(xpath = "//button[@class='btn btn-sm btn-info ng-binding ng-scope' and contains(text(),'Today')]")
	WebElement datetodaybtn;
	@FindBy(xpath = "//button[@class='btn btn-sm btn-info ng-binding ng-scope' and contains(text(),'Now')]")
	WebElement datenowbtn;
	@FindBy(xpath = "//div[@id='select_work_queue_chosen']")
	WebElement workqueue;
	@FindBy(xpath = "//div[@id='select_Assigned_chosen']")
	WebElement assigned;
	@FindBy(xpath = "//div[@id='select_severity_chosen']")
	WebElement sevr;
	@FindBy(xpath = "//div[@id='select_medium_chosen']")
	WebElement sourcemed;
	@FindBy(xpath = "//div[@id='select_impact_chosen']")
	WebElement impact;
	@FindBy(xpath = "//div[@class='form-field-container form-field-container']//label[contains(.,'Transported')]/following-sibling::div//a")
	WebElement transportused;
	@FindBy(xpath = "//label[contains(text(),'Region')]/following-sibling::div/div/a/span[contains(text(),'Select')]")
	WebElement regionselect;
	@FindBy(xpath = "//li[@class='active-result' and contains(text(),'Albuquerque')]")
	WebElement regionalbuquerque;
	@FindBy(xpath = "//label[contains(text(),'Type of Response')]/following-sibling::div/div/a/span[contains(text(),'Select')]")
	WebElement typeofresponse;
	@FindBy(xpath = "//li[@class='active-result' and contains(text(),'Branch Report of Customer Injury')]")
	WebElement typeresponse;
	@FindBy(xpath = "//label[contains(text(),'Building')]/following-sibling::div/div/a/span[contains(text(),'Select')]")
	WebElement building;
	@FindBy(xpath = "//li[@class='active-result' and contains(text(),'Investor Center 134 - Scottsdate, AZ')]")
	WebElement buildinginvestigator;
	@FindBy(css = "#select_Assigned_chosen > a > span")
	WebElement assignedto;
	@FindBy(xpath = "//*[@id='medicalForm']/div/div/div[1]/div[1]/div[4]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement securityresponse;
	@FindBy(xpath = "//*[@id='medicalForm']/div/div/div[1]/div[1]/div[7]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement rsotEMTresponded;
	@FindBy(xpath = "//*[@id='securityTimeOfNotification-parent']/span[1]/button/i")
	WebElement timeofnot;
	@FindBy(xpath = "//*[@id='medicalForm']/div/div/div[2]/div[2]/div[6]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement vitalsTaken;
	@FindBy(xpath = "//button[contains(.,'Illness')]")
	WebElement illnesstoggle;
	@FindBy(xpath = "//*[@id='medicalForm']/div/div/div[2]/div[3]/div[13]/toggle-switch/div[1]/div/fieldset/button[1]")
	WebElement ptntrefcaretogl;
	@FindBy(xpath = "//*[@id='medicalForm']/div/div/div[1]/div[2]/div[5]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement emsresponse;
	@FindBy(xpath = "//button[@class='button-component button--secondary mlg--button' and contains(text(),'Create Case')]")
	WebElement createcasebutton;
	@FindBy(xpath = "//a[@class='mlg-cancel-button' and contains(text(),'Clear Fields')]")
	WebElement clearfieldsbutton;
	@FindBy(xpath = "//button[@class='btn btn-primary ng-binding' and contains(text(),'Yes')]")
	WebElement clearfieldsYesbutton;
	@FindBy(xpath = "//a[@ng-click ='CancelCase(true)' and contains(text(),'Cancel')]")
	WebElement cancelbutton;
	@FindBy(xpath = "/html/body/div[1]/div/div/div/div[2]/button[2]")
	WebElement cancelyesbutton;

	public MedicalCasePageObjects() {
		PageFactory.initElements(driver, this);
	}
}
