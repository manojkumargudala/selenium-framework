package com.sheildqa.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ComponentsPageObjects extends PageFooter {
	@FindBy(xpath = "//*[@id='caseForm']/div/div[1]/div/div/a[3]")
	WebElement notes;
	@FindBy(xpath = "//input[@ng-model='note.noteTopic']")
	WebElement notetopic;
	@FindBy(xpath = "//a[@class='chosen-single']//span[contains(text(),'Select Note Type')]")
	WebElement notetype;
	@FindBy(xpath = "//li[@class='active-result' and contains(text(),'Narrative')]")
	WebElement notetypedrpdwn;
	@FindBy(xpath = "//*[@id='notesForm']/div[2]/div/div[2]/div/textarea")
	WebElement notescontent;
	@FindBy(xpath = "//*[@id='caseForm']/div/div[1]/div/div/a[4]/div[1]")
	WebElement documents;
	@FindBy(xpath = "//*[@id='caseForm']/div/div[1]/div/div/a[5]/div[1]")
	WebElement associatedentity;
	@FindBy(xpath = "//*[@id='caseForm']/div/div[1]/div/div/a[6]")
	WebElement missingproperty;
	@FindBy(xpath = "//*[@id='caseForm']/div/div[1]/div/div/a[9]")
	WebElement parcel;
	@FindBy(xpath = "//*[@id='caseForm']/div/div[1]/div/div/a[7]/div[1]")
	WebElement vehicle;
	@FindBy(xpath = "//*[@id='caseForm']/div/div[1]/div/div/a[8]")
	WebElement vendorservice;
	@FindBy(xpath = "//*[@id='caseForm']/div/div[1]/div/div/a[11]/div")
	WebElement audit;

	public ComponentsPageObjects() {
		PageFactory.initElements(driver, this);
	}
}
