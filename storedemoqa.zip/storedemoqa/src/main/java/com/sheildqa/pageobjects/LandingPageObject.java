package com.sheildqa.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LandingPageObject extends PageFooter {

	@FindBy(xpath = "//img[@class='float-left']")
	WebElement imageShield;
	@FindBy(xpath = "//h4[@class='mlg--h4 float-right navbar-name ng-binding']")
	WebElement loginnametext;
	@FindBy(xpath = "//div[@class='queue-quantity-font-size ng-binding'][contains(text(),'Cases')]")
	WebElement casestab;
	WebElement alertstab;
	@FindBy(xpath = "//h3[@class='mlg--h3 inline-block padding0']")
	WebElement createcasetext;
	@FindBy(xpath = "//div[@class='case-quantity-font-size ng-binding' and contains(text(),'My Cases')]")
	WebElement myCasestab;
	@FindBy(xpath = "//div[@class='case-quantity-font-size ng-binding' and contains(text(),'Active cases')]")
	WebElement activeCasestab;
	@FindBy(xpath = "//div[@class='case-quantity-font-size ng-binding' and contains(text(),'Cases for Review')]")
	WebElement casesforreviewtab;
	@FindBy(xpath = "//button[@ng-click='logout()']")
	WebElement gobutton1;
	@FindBy(xpath = "//div[@class='case-quantity-font-size ng-binding' and contains(text(),'My Cases')]")
	WebElement pagination;
	@FindBy(xpath = "//div[@class='fidgrid--col']")
	WebElement rightPane;
	@FindBy(xpath = "//li[@class='active-result' and contains(text(),'Life Safety')]")
	WebElement lifeSafety;

	public LandingPageObject() {
		PageFactory.initElements(driver, this);
	}
}
