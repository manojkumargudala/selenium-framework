package com.sheildqa.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SuspiciousItemCasePageObjects extends PageFooter {
	@FindBy(xpath = "//*[@id='suspForm']/div/div/div/div[2]/div[1]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement businessimpact;
	@FindBy(xpath = "//*[@id='suspForm']/div/div/div/div[2]/div[2]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement escalation;
	@FindBy(xpath = "//*[@id='securityTimeOfDispatch-parent']/span[1]/button")
	WebElement timeofdpatch;
	@FindBy(xpath = "//*[@id='datepicker-3795-5399-9']/button")
	WebElement randomday;
	@FindBy(xpath = "//*[@id='securityTimeOfArrival-parent']/span[1]/button/i")
	WebElement timeofarrival;
	@FindBy(xpath = "//*[@id='suspForm']/div/div/div/div[2]/div[5]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement outsideauthcontct;
	@FindBy(xpath = "//label[contains(text(),'Detected  By')]/following-sibling::div/div/a/span[contains(text(),'Select')]")
	WebElement detectedby;
	@FindBy(xpath = "//*[@id='suspForm']/div/div/div/div[2]/div[9]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement evacuation;
	@FindBy(xpath = "//*[@id='suspForm']/div/div/div/div[2]/div[11]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement shelterinspace;
	@FindBy(xpath = "//*[@id='suspForm']/div/div/div/div[1]/div[10]/toggle-switch/div[1]/div/fieldset/button[2]")
	WebElement initiateduresactv;

	public SuspiciousItemCasePageObjects() {
		PageFactory.initElements(driver, this);
	}
}
