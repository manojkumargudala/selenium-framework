package com.sheildqa.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class PageFooter extends PageHeader {
	@FindBy(xpath = ".//a[text()='SP Home']")
	WebElement spHome;
	@FindBy(xpath = ".//a[text()='Sample Page']")
	WebElement samplePage;
	@FindBy(xpath = ".//a[text()='Your Account']")
	WebElement yourAccount;

	public void clickSpHomeLink() {
		wait.until(ExpectedConditions.visibilityOf(spHome));
		spHome.click();
	}

}
