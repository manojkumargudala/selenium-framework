package com.sheildqa.pageobjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AlertDetailsPageObjects extends PageFooter {
	@FindBy(xpath = "//*[@id='addalertForm']/div/div[1]/div[1]/div[1]/div[1]/div/input")
	WebElement alertname;
	@FindBy(xpath = "//*[@id='addalertForm']/div/div[2]/div/div/div[1]/div/textarea")
	WebElement predication;
	@FindBy(xpath = "//*[@id='alertTimeOfNotification-parent']/span[1]/button")
	WebElement atimeofnot;
	@FindBy(xpath = "//*[@id='alertTimeOfNotification-parent']/span[1]/button")
	WebElement atimeofdispacth;
	@FindBy(css = "ng-scope")
	WebElement caseId;

	public AlertDetailsPageObjects() {
		PageFactory.initElements(driver, this);
	}
}
