package com.sheildqa.testcases;

//import java.awt.List;
import java.util.ArrayList;
import java.util.List;
//import java.
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class LandingPage {

	private static final String system = null;
	protected WebDriver driver;

	public LandingPage(WebDriver driver) {
		this.driver = driver;
	}

	public By hamburger = By.xpath("//em[@class='fa fa-navicon']");
	public By changeuserinput = By
			.xpath("//input[@class='form-control text-field PIN--input ng-pristine ng-valid ng-empty ng-touched']");
	public By changeuserinput11 = By.xpath("//input[@ng-model='testCorpId']");
	public By imageShield = By.xpath("//img[@class='float-left']");
	public By loginnametext = By.xpath("//h4[@class='mlg--h4 float-right navbar-name ng-binding']");
	public By casestab = By.xpath("//div[@class='queue-quantity-font-size ng-binding'][contains(text(),'Cases')]");
	public By alertstab = By.xpath("//div[@class='queue-quantity-font-size ng-binding'][contains(text(),'Alerts')]");
	public By createcasetext = By.xpath("//h3[@class='mlg--h3 inline-block padding0']");
	public By myCasestab = By
			.xpath("//div[@class='case-quantity-font-size ng-binding' and contains(text(),'My Cases')]");
	public By activeCasestab = By
			.xpath("//div[@class='case-quantity-font-size ng-binding' and contains(text(),'Active cases')]");
	public By casesforreviewtab = By
			.xpath("//div[@class='case-quantity-font-size ng-binding' and contains(text(),'Cases for Review')]");
	public By gobutton1 = By.xpath("//button[@ng-click='logout()']");
	public By pagination = By
			.xpath("//div[@class='case-quantity-font-size ng-binding' and contains(text(),'My Cases')]");
	public By goButton = By.xpath("//button[@id='case-go-button']");
	public By rightPane = By.xpath("//div[@class='fidgrid--col']");
	public By lifeSafety = By.xpath("//li[@class='active-result' and contains(text(),'Life Safety')]");
	/*--  medical fields ---*/
	public By classnameinput = By.xpath("//input[@ng-model='caseDetails.origin.caseName']");
	public By occureddate = By.xpath("//i[@class='fa fa-calendar']");
	public By datetodaybtn = By
			.xpath("//button[@class='btn btn-sm btn-info ng-binding ng-scope' and contains(text(),'Today')]");
	public By datenowbtn = By
			.xpath("//button[@class='btn btn-sm btn-info ng-binding ng-scope' and contains(text(),'Now')]");
	public By workqueue = By.xpath("//div[@id='select_work_queue_chosen']");
	public By assigned = By.xpath("//div[@id='select_Assigned_chosen']");
	public By sevr = By.xpath("//div[@id='select_severity_chosen']");
	public By sourcemed = By.xpath("//div[@id='select_medium_chosen']");
	public By impact = By.xpath("//div[@id='select_impact_chosen']");
	public By transportused = By.xpath(
			"//div[@class='form-field-container form-field-container']//label[contains(.,'Transported')]/following-sibling::div//a");
	public By regionselect = By
			.xpath("//label[contains(text(),'Region')]/following-sibling::div/div/a/span[contains(text(),'Select')]");

	public By regionalbuquerque = By.xpath("//li[@class='active-result' and contains(text(),'Albuquerque')]");
	public By typeofresponse = By.xpath(
			"//label[contains(text(),'Type of Response')]/following-sibling::div/div/a/span[contains(text(),'Select')]");
	public By typeresponse = By
			.xpath("//li[@class='active-result' and contains(text(),'Branch Report of Customer Injury')]");
	public By building = By
			.xpath("//label[contains(text(),'Building')]/following-sibling::div/div/a/span[contains(text(),'Select')]");
	public By buildinginvestigator = By
			.xpath("//li[@class='active-result' and contains(text(),'Investor Center 134 - Scottsdate, AZ')]");
	public By assignedto = By.cssSelector("#select_Assigned_chosen > a > span");
	public By securityresponse = By
			.xpath("//*[@id='medicalForm']/div/div/div[1]/div[1]/div[4]/toggle-switch/div[1]/div/fieldset/button[2]");
	public By rsotEMTresponded = By
			.xpath("//*[@id='medicalForm']/div/div/div[1]/div[1]/div[7]/toggle-switch/div[1]/div/fieldset/button[2]");
	public By timeofnot = By.xpath("//*[@id='securityTimeOfNotification-parent']/span[1]/button/i");
	public By vitalsTaken = By
			.xpath("//*[@id='medicalForm']/div/div/div[2]/div[2]/div[6]/toggle-switch/div[1]/div/fieldset/button[2]");
	public By illnesstoggle = By.xpath("//button[contains(.,'Illness')]");
	public By ptntrefcaretogl = By
			.xpath("//*[@id='medicalForm']/div/div/div[2]/div[3]/div[13]/toggle-switch/div[1]/div/fieldset/button[1]");
	public By emsresponse = By
			.xpath("//*[@id='medicalForm']/div/div/div[1]/div[2]/div[5]/toggle-switch/div[1]/div/fieldset/button[2]");
	public By createcasebutton = By.xpath(
			"//button[@class='button-component button--secondary mlg--button' and contains(text(),'Create Case')]");
	public By clearfieldsbutton = By.xpath("//a[@class='mlg-cancel-button' and contains(text(),'Clear Fields')]");
	public By clearfieldsYesbutton = By
			.xpath("//button[@class='btn btn-primary ng-binding' and contains(text(),'Yes')]");
	public By cancelbutton = By.xpath("//a[@ng-click ='CancelCase(true)' and contains(text(),'Cancel')]");
	public By cancelyesbutton = By.xpath("/html/body/div[1]/div/div/div/div[2]/button[2]");
	/** suspiciousitem fields */
	public By businessimpact = By
			.xpath("//*[@id='suspForm']/div/div/div/div[2]/div[1]/toggle-switch/div[1]/div/fieldset/button[2]");
	public By escalation = By
			.xpath("//*[@id='suspForm']/div/div/div/div[2]/div[2]/toggle-switch/div[1]/div/fieldset/button[2]");
	public By timeofdpatch = By.xpath("//*[@id='securityTimeOfDispatch-parent']/span[1]/button");
	public By randomday = By.xpath("//*[@id='datepicker-3795-5399-9']/button");
	public By timeofarrival = By.xpath("//*[@id='securityTimeOfArrival-parent']/span[1]/button/i");
	public By outsideauthcontct = By
			.xpath("//*[@id='suspForm']/div/div/div/div[2]/div[5]/toggle-switch/div[1]/div/fieldset/button[2]");
	public By detectedby = By.xpath(
			"//label[contains(text(),'Detected  By')]/following-sibling::div/div/a/span[contains(text(),'Select')]");
	public By evacuation = By
			.xpath("//*[@id='suspForm']/div/div/div/div[2]/div[9]/toggle-switch/div[1]/div/fieldset/button[2]");
	public By shelterinspace = By
			.xpath("//*[@id='suspForm']/div/div/div/div[2]/div[11]/toggle-switch/div[1]/div/fieldset/button[2]");
	public By initiateduresactv = By
			.xpath("//*[@id='suspForm']/div/div/div/div[1]/div[10]/toggle-switch/div[1]/div/fieldset/button[2]");
	/** components */
	public By notes = By.xpath("//*[@id='caseForm']/div/div[1]/div/div/a[3]");
	public By notetopic = By.xpath("//input[@ng-model='note.noteTopic']");
	public By notetype = By.xpath("//a[@class='chosen-single']//span[contains(text(),'Select Note Type')]");
	public By notetypedrpdwn = By.xpath("//li[@class='active-result' and contains(text(),'Narrative')]");

	public By notescontent = By.xpath("//*[@id='notesForm']/div[2]/div/div[2]/div/textarea");
	public By documents = By.xpath("//*[@id='caseForm']/div/div[1]/div/div/a[4]/div[1]");
	public By associatedentity = By.xpath("//*[@id='caseForm']/div/div[1]/div/div/a[5]/div[1]");
	// public By choosedoc= By.xpath("");
	// public By fidelityaffiliation= By.xpath("");
	// public By caseassociation= By.xpath("");
	public By missingproperty = By.xpath("//*[@id='caseForm']/div/div[1]/div/div/a[6]");
	// public By propertycategory= By.xpath("");
	// public By propertyownership= By.xpath("");
	// public By propertytype= By.xpath("");
	// public By takenbyfidelity= By.xpath("");
	public By parcel = By.xpath("//*[@id='caseForm']/div/div[1]/div/div/a[9]");
	public By vehicle = By.xpath("//*[@id='caseForm']/div/div[1]/div/div/a[7]/div[1]");
	// public By vehicletype= By.xpath("");
	// public By color= By.xpath("");
	public By vendorservice = By.xpath("//*[@id='caseForm']/div/div[1]/div/div/a[8]");
	// public By vendor= By.xpath("");
	public By audit = By.xpath("//*[@id='caseForm']/div/div[1]/div/div/a[11]/div");
	/** ----alert details page----- */
	public By alertname = By.xpath("//*[@id='addalertForm']/div/div[1]/div[1]/div[1]/div[1]/div/input");
	public By predication = By.xpath("//*[@id='addalertForm']/div/div[2]/div/div/div[1]/div/textarea");
	public By atimeofnot = By.xpath("//*[@id='alertTimeOfNotification-parent']/span[1]/button");
	public By atimeofdispacth = By.xpath("//*[@id='alertTimeOfNotification-parent']/span[1]/button");

	public By caseId = By.className("ng-scope");
	/*
	 * public By caseName = By.xpath(
	 * "//input[@class='ui-grid-filter-input ui-grid-filter-input-0 ng-empty ng-touched']"
	 * ); public By status = By.xpath(
	 * "//input[@class='ui-grid-filter-input ui-grid-filter-input-0 ng-empty ng-touched']"
	 * ); public By occuredDate = By.xpath(
	 * "//input[@class='ui-grid-filter-input ui-grid-filter-input-0 ng-empty ng-touched']"
	 * ); public By caseClass = By.xpath(
	 * "//input[@class='ui-grid-filter-input ui-grid-filter-input-0 ng-empty ng-touched']"
	 * ); public By caseType = By.xpath(
	 * "//input[@class='ui-grid-filter-input ui-grid-filter-input-0 ng-empty ng-touched']"
	 * ); public By workQueue = By.xpath(
	 * "//input[@class='ui-grid-filter-input ui-grid-filter-input-0 ng-empty ng-touched']"
	 * ); public By assignedTo = By.xpath(
	 * "//input[@class='ui-grid-filter-input ui-grid-filter-input-0 ng-empty ng-touched']"
	 * );
	 */
	public By search = By.xpath("//em[@class='fa fa-search']");
	public By caseclass = By.xpath("//label[contains(text(),'Case Class ')]/span");

	/**
	 * -- change the login for getting all permissons--
	 * 
	 * @throws InterruptedException
	 **/

	public void hamBurger() throws InterruptedException {

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement hamburger1 = driver.findElement(hamburger);
		hamburger1.click();
		Thread.sleep(3000);

		System.out.println("hamburger clicked");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement changeuserinput1 = driver.findElement(changeuserinput11);
		changeuserinput1.sendKeys("a024183");
		System.out.println("input enterd");

		WebElement goButton = driver.findElement(gobutton1);
		goButton.click();
		Thread.sleep(4000);
		System.out.println("Verified Go button");
	}

	/** --Verify the image of shield on the page-- **/
	public void VerifyImage() throws Exception {
		try {
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			String title = driver.getTitle();
			System.out.println(title);
			WebElement img = driver.findElement(imageShield);
			System.out.println("Image Shield is verified");

		} catch (Exception e) {
			throw e;
		}
	}

	/** --Verify the loginname on the page-- **/
	public void VerifyLoginName() {
		System.out.println("verifying the login name");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String loginname = driver.findElement(loginnametext).getText();
		System.out.println(loginname);
		Assert.assertTrue(loginname.toLowerCase().contains(("Welcome").toLowerCase()));
		System.out.println("Verified the login name is present on the page");
	}

	/** --Verify the tabs on the page-- **/
	public void VerifyTabs() {
		System.out.println("Verify the tabs on the page");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement casetab = driver.findElement(casestab);
		System.out.println("Verified the cases tab");
		WebElement alerttab = driver.findElement(alertstab);
		System.out.println("Verified the alert tab");
		WebElement mycasetab = driver.findElement(myCasestab);
		System.out.println("Verified the mycases tab");
		WebElement activecasestab1 = driver
				.findElement(By.xpath("//a[@class='btn mlg-font queue-button-position']/div"));
		activecasestab1.click();
		System.out.println("Verified the activecases tab");
		System.out.println("Verified the Cases for review");
		WebElement casesForreview = driver.findElement(casesforreviewtab);
		casesForreview.click();
		System.out.println("Verified the Cases for review tab");
	}

	/** --Verify the createcase text-- **/
	public void createcaseText() {
		System.out.println("verifying the create case text");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String createCase = driver.findElement(createcasetext).getText();
		System.out.println("Verified that create case text is present");
	}

	/** --Verify the rightpane-- **/

	public void rightpane() {
		System.out.println("verifying the crightpane existance");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement rightpane1 = driver.findElement(rightPane);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("Verified that right pane is present");
	}

	/** --Verify the filer option-- **/

	public void VerifyFilter() throws InterruptedException {
		System.out.println(" Verify the filter option is present");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		WebElement caseidfilte = driver.findElement(By.xpath(
				"//div[contains(@id,'menu-button')]/following-sibling::div[1]/div/div/input[contains(@class,'ui-grid-filter-input ui-grid-filter-input-0 ng-empty ng-touched')]"));
		caseidfilte.click();
		WebElement casenamefilter = driver.findElement(By.xpath(
				"//div[@id='1482718003048-uiGrid-0007-menu-button']/following-sibling::div[1]/div/div/input[@class='ui-grid-filter-input ui-grid-filter-input-0 ng-empty ng-touched']"));
		casenamefilter.click();

	}

	/** --Verify the search functionality-- **/

	public void SearchFunctionlity() throws InterruptedException {
		System.out.println("Verifying the search form functionality");
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		WebElement searchbtn = driver.findElement(search);
		searchbtn.click();
		Thread.sleep(4000);
		/** --handling the window tabs here-- **/
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		System.out.println("Navigated to child window");
		driver.close();
		driver.switchTo().window(tabs2.get(0));
		System.out.println("Verified the search is clicked and opened the attivio");

	}

	/** --Verify the pagination functionality-- **/

	public void VerifyPagination() {
		String cases = null;
		int totalcases;
		String totalpages = null;
		int totalpagenumbers;
		int totalcaseids = 0;
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String mycasestext = driver.findElement(pagination).getText();
		System.out.println(mycasestext);
		String[] split = mycasestext.split("\\s+");
		for (int i = 0; i < split.length; i++) {
			Integer.parseInt(split[i]);
			System.out.println("The " + split[i] + " value is integer");
			cases = split[i];

			break;
		}
		totalcases = Integer.valueOf(cases);
		System.out.println(totalcases);
		String pages = driver.findElement(By.xpath("//span[@class='ui-grid-pager-max-pages-number ng-binding'][1]"))
				.getText();
		System.out.println(pages);
		String[] splittotalpages = pages.split("\\s+");
		for (int i = 0; i < splittotalpages.length; i++) {
			Integer.parseInt(splittotalpages[i + 1]);
			System.out.println(splittotalpages[i + 1] + " valid integer");
			totalpages = splittotalpages[i + 1];
			break;
		}
		totalpagenumbers = Integer.valueOf(totalpages);
		for (int j = 1; j <= totalpagenumbers; j++) {
			int caseids = driver
					.findElements(By.xpath("//a[@class='margin-left-5 ng-binding' and contains(text(),'SC')]")).size();
			System.out.println(caseids);
			totalcaseids = totalcaseids + caseids;
			if (totalcaseids == totalcases) {
				break;
			} else {
				WebElement clicknext = driver.findElement(By.xpath("//button[@class='ui-grid-pager-next']"));
				clicknext.click();
				continue;
			}
		}
		System.out.println("total cases verified");
	}

	public void commonCaseDetails() throws InterruptedException {
		WebElement caseNameinput = driver.findElement(classnameinput);
		caseNameinput.sendKeys("Test");
		Thread.sleep(2000);
		System.out.println("input given");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(2000);
		WebElement date = driver.findElement(occureddate);
		date.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(datetodaybtn).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(datenowbtn).click();
		WebElement workQueue = driver.findElement(workqueue);
		workQueue.click();
		driver.findElement(By.xpath("//li[contains(.,'Albuquerque')]")).click();
		WebElement assign = driver.findElement(assigned);
		assign.click();
		driver.findElement(By.xpath("//li[contains(.,'BURNS, JULIE   A367411')]")).click();
		WebElement svr = driver.findElement(sevr);
		svr.click();
		driver.findElement(By.xpath("//div[@id='select_severity_chosen']//li[contains(.,'E')]")).click();
		WebElement srcm = driver.findElement(sourcemed);
		srcm.click();
		driver.findElement(By.xpath("//li[contains(.,'Alarm')]")).click();
		java.util.List<WebElement> impac = driver.findElements(impact);
		System.out.print(impac.size());
		for (WebElement imps : impac) {
			if (imps.isDisplayed()) {
				imps.click();
			}

		}
		driver.findElement(By.xpath("//li[contains(.,'External')]")).click();
		driver.findElement(regionselect).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(regionalbuquerque).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(building).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(buildinginvestigator).click();
		Thread.sleep(4000);

	}

	/** -- creating a case-- **/
	public void CaseClass() throws InterruptedException {
		hamBurger();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement caseclass1 = driver.findElement(caseclass);
		WebElement caseclassdropdown = driver.findElement(By.xpath("//div[@id='athena_create_case_chosen']"));
		WebElement casetype = driver.findElement(By.xpath("//label[contains(text(),'Case Type ')]/span"));
		WebElement casetypedropdown = driver.findElement(By.xpath("//div[@id='create_type_chosen']"));

		WebElement caseclassselect = driver
				.findElement(By.xpath("//div[@id='athena_create_case_chosen']/a/span[contains(text(),'Select')]"));
		caseclassselect.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement lifesafety = driver.findElement(lifeSafety);
		lifesafety.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		WebElement casetypeselect = driver
				.findElement(By.xpath("//a[@class='chosen-single chosen-default']/span[contains(text(),'Select')]"));
		casetypeselect.click();
		Thread.sleep(1000);
		WebElement casetypeMedical = driver.findElement(By.xpath("//*[@id='create_type_chosen']/div/ul/li[8]"));
		casetypeMedical.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(goButton).click();
		Thread.sleep(4000);

		/** -- medical casedetails page-- */
		commonCaseDetails();
		driver.findElement(typeofresponse).click();
		driver.findElement(typeresponse).click();

		WebElement timeofNot = driver.findElement(timeofnot);
		timeofNot.click();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(datetodaybtn).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.findElement(datenowbtn).click();

		WebElement securityResponse = driver.findElement(securityresponse);
		securityResponse.click();
		System.out.println();
		WebElement emsresponseno = driver.findElement(emsresponse);
		emsresponseno.click();
		System.out.println();

		WebElement rsotEMTResponded = driver.findElement(rsotEMTresponded);
		rsotEMTResponded.click();
		WebElement illnessToggle = driver.findElement(illnesstoggle);
		illnessToggle.click();
		WebElement vitalstaken = driver.findElement(vitalsTaken);
		vitalstaken.click();

		Thread.sleep(4000);

		List<WebElement> illnessDropdwn = driver.findElements(By.xpath(
				"//div[@class='input-single-field--container mlg-input-error-container']//div[@class='chosen-container chosen-container-multi']"));
		for (WebElement trn : illnessDropdwn) {
			if (trn.isDisplayed()) {
				trn.click();
				break;
			}

		}
		Thread.sleep(500);
		driver.findElement(By.xpath("//li[contains(.,'Body Pain')]")).click();

		Thread.sleep(500);
		java.util.List<WebElement> trnsport = driver.findElements(transportused);
		System.out.print(trnsport.size());
		WebElement trans = trnsport.get(0);
		trans.click();
		for (WebElement trn : trnsport) {
			if (trn.isDisplayed()) {
				trn.click();
				break;
			}

		}
		Actions acvtion = new Actions(driver);
		acvtion.sendKeys(Keys.SPACE).build().perform();
		driver.findElement(By.xpath("//li[contains(.,'Ambulance')]")).click();
		System.out.println();
		WebElement ptntrefcareTgl = driver.findElement(ptntrefcaretogl);
		ptntrefcareTgl.click();
		System.out.println();

	}

	public void caseoperations() throws InterruptedException {
		/**
		 * CaseClass(); WebElement cancelButton=
		 * driver.findElement(cancelbutton); cancelButton.click(); WebElement
		 * cancelYesButton= driver.findElement(cancelyesbutton);
		 * cancelYesButton.click(); System.out.println(
		 * "Verified the cancel operation"); CaseClass(); WebElement
		 * clearFieldsbutton= driver.findElement(clearfieldsbutton);
		 * clearFieldsbutton.click(); WebElement clearFieldsNobutton=
		 * driver.findElement(clearfieldsYesbutton);
		 * clearFieldsNobutton.click(); System.out.println(
		 * "Verified the clear text field operation");
		 * 
		 * Thread.sleep(5000);
		 */

		CaseClass();
		WebElement createCasebutton = driver.findElement(createcasebutton);
		createCasebutton.click();
		System.out.println("Verified the create case operation");
		Thread.sleep(5000);
	}

	public void components() throws InterruptedException {
		WebElement notesicon = driver.findElement(notes);
		notesicon.click();
		WebElement noteTopic = driver.findElement(notetopic);
		noteTopic.sendKeys("testing Notes topic");
		WebElement noteContent = driver.findElement(notescontent);
		noteContent.sendKeys("testing Notes content");

		WebElement noteType = driver.findElement(notetype);
		noteType.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement noteTypeDrpdwn = driver.findElement(notetypedrpdwn);
		noteTypeDrpdwn.click();
		Thread.sleep(500);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println("verifed notes component");
		WebElement documenticon = driver.findElement(documents);
		documenticon.click();
		WebElement docdesc = driver.findElement(By.xpath("//*[@id='documentForm']/div[3]/div[1]/div[1]/div/div/input"));
		docdesc.sendKeys("testing document desc");
		System.out.println("verifed the document component");
		// *[@id="notesForm"]/div[2]/div/div[3]/div[1]/button

		WebElement associatedEntity = driver.findElement(associatedentity);
		associatedEntity.click();
		WebElement associatedEntitytogle = driver.findElement(
				By.xpath("//*[@id='case-associated-form']/div[4]/div/toggle-switch/div[1]/div/fieldset/button[2]"));
		associatedEntitytogle.click();
		WebElement fidaff = driver.findElement(By.xpath(
				"//label[contains(text(),'Fidelity Affiliation')]/following-sibling::div/div/a/span[contains(text(),'Select')]"));
		fidaff.click();
		WebElement fidaffdrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'Contractor')]"));
		fidaffdrpdwn.click();

		WebElement caseAssoc = driver.findElement(By.xpath(
				"//label[contains(text(),'Case Association')]/following-sibling::div/div/a/span[contains(text(),'Select')]"));
		caseAssoc.click();
		WebElement caseAssocdrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'Patient')]"));
		caseAssocdrpdwn.click();

		WebElement missingProperty = driver.findElement(missingproperty);
		missingProperty.click();
		WebElement proCate = driver.findElement(By.xpath(
				"//label[@class='form-label mlg-label athena-label' and contains(text(),'Property Category')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		proCate.click();
		WebElement procategrydrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'Computer')]"));
		procategrydrpdwn.click();
		WebElement lostStolentogl = driver.findElement(By.xpath(
				"//*[@id='propform']/div/div[1]/div/div/div[1]/div[2]/toggle-switch/div[1]/div/fieldset/button[2]"));
		lostStolentogl.click();
		WebElement dateOccured = driver
				.findElement(By.xpath("//*[@id='missing-prop-date-reported-parent']/span[1]/button/i"));
		dateOccured.click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(datetodaybtn).click();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.findElement(datenowbtn).click();
		WebElement locType = driver.findElement(By.xpath(
				"//label[@class='form-label mlg-label athena-label' and contains(text(),'Location Type')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		locType.click();
		WebElement locTypedrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'Airport')]"));
		locTypedrpdwn.click();

		WebElement propOwnrType = driver.findElement(By.xpath(
				"//label[@class='form-label mlg-label athena-label' and contains(text(),'Property Ownership')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		propOwnrType.click();
		WebElement propOwndrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'Company')]"));
		propOwndrpdwn.click();

		WebElement propType = driver.findElement(By.xpath(
				"//label[@class='form-label mlg-label athena-label' and contains(text(),'Property Type')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		propType.click();
		WebElement propTypedrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'Desktop')]"));
		propTypedrpdwn.click();

		WebElement recoveredTogl = driver.findElement(By.xpath(
				"//*[@id='propform']/div/div[1]/div/div/div[2]/div[9]/div[1]/toggle-switch/div[1]/div/fieldset/button[2]"));
		recoveredTogl.click();
		WebElement privacyIssue = driver.findElement(By.xpath(
				"//*[@id='propform']/div/div[1]/div/div/div[2]/div[9]/div[3]/toggle-switch/div[1]/div/fieldset/button[2]"));
		privacyIssue.click();
		// WebElement taknbyFid =
		// driver.findElement(By.xpath("//label[@class='form-label mlg-label
		// athena-label' and [contains(text(),'Taken by Fidelity/Associate
		// Contractor?')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		// taknbyFid.click();
		// WebElement taknbyFiddrpdwn =
		// driver.findElement(By.xpath("//li[@class='active-result' and
		// contains(text(),'No')]"));
		// taknbyFiddrpdwn.click();

		WebElement policeReprtfiled = driver.findElement(By.xpath(
				"//*[@id='propform']/div/div[1]/div/div/div[1]/div[14]/div[1]/toggle-switch/div[1]/div/fieldset/button[2]"));
		policeReprtfiled.click();
		System.out.println("verifed the missing property component");
		WebElement vehiclecomp = driver.findElement(vehicle);
		vehiclecomp.click();
		WebElement vehicleType = driver.findElement(By.xpath(
				"//label[@class='form-label mlg-label athena-label' and contains(text(),'Vehicle Type')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		propOwnrType.click();
		WebElement vehicleTypedrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'Car')]"));
		vehicleTypedrpdwn.click();
		WebElement color = driver.findElement(By.xpath(
				"//label[@class='form-label mlg-label athena-label' and contains(text(),'Color')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		color.click();
		WebElement colordrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'Red')]"));
		color.click();
		WebElement vendorService = driver.findElement(vendorservice);
		vendorService.click();
		WebElement vendorfield = driver.findElement(By.xpath(
				"//label[@class='form-label mlg-label athena-label' and contains(text(),'Vendor')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		vendorfield.click();
		WebElement vendordrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'BPI')]"));
		vendordrpdwn.click();
		WebElement parcelComp = driver.findElement(parcel);
		parcelComp.click();
		WebElement deliveryMthd = driver.findElement(By.xpath(
				"//label[@class='form-label mlg-label athena-label' and contains(text(),'Delivery Method')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		deliveryMthd.click();
		WebElement deliveryMthddrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'CDS')]"));
		deliveryMthd.click();
		WebElement mailType = driver.findElement(By.xpath(
				"//label[@class='form-label mlg-label athena-label' and contains(text(),'Vendor')]/following-sibling::div/fieldset/div/a/span[contains(text(),'Select')]"));
		mailType.click();
		WebElement mailTypedrpdwn = driver
				.findElement(By.xpath("//li[@class='active-result' and contains(text(),'Email')]"));
		mailTypedrpdwn.click();
		WebElement vendorReviewedtogl = driver.findElement(By.xpath(
				"//*[@id='parcelForm']/div/div/div[1]/div/div[2]/div[16]/toggle-switch/div[1]/div/fieldset/button[2]"));
		vendorReviewedtogl.click();
		WebElement scannedBymailTogl = driver.findElement(By.xpath(
				"//*[@id='parcelForm']/div/div/div[1]/div/div[2]/div[17]/toggle-switch/div[1]/div/fieldset/button[2]"));
		scannedBymailTogl.click();

		WebElement auditComp = driver.findElement(audit);
		auditComp.click();

	}

	/*---- suspicious item details page---*/
	public void suspiciousItem() throws InterruptedException {
		hamBurger();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement caseclass1 = driver.findElement(caseclass);
		WebElement caseclassdropdown = driver.findElement(By.xpath("//div[@id='athena_create_case_chosen']"));
		WebElement casetype = driver.findElement(By.xpath("//label[contains(text(),'Case Type ')]/span"));
		WebElement casetypedropdown = driver.findElement(By.xpath("//div[@id='create_type_chosen']"));

		WebElement caseclassselect = driver
				.findElement(By.xpath("//div[@id='athena_create_case_chosen']/a/span[contains(text(),'Select')]"));
		caseclassselect.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		WebElement lifesafety = driver.findElement(lifeSafety);
		lifesafety.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		WebElement casetypeselect = driver
				.findElement(By.xpath("//a[@class='chosen-single chosen-default']/span[contains(text(),'Select')]"));
		casetypeselect.click();
		Thread.sleep(1000);
		WebElement casetypeSuspiciousItem = driver.findElement(By.xpath("//*[@id='create_type_chosen']/div/ul/li[9]"));
		casetypeSuspiciousItem.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(goButton).click();
		Thread.sleep(4000);
		commonCaseDetails();
		WebElement businessImpact = driver.findElement(businessimpact);
		businessImpact.click();
		WebElement escalationTogl = driver.findElement(escalation);
		escalationTogl.click();
		WebElement timeofDpatch = driver.findElement(timeofdpatch);
		timeofDpatch.click();
		driver.findElement(randomday).click();
		WebElement dateClosebtn = driver.findElement(By.xpath("/html/body/ul[2]/li[2]/span[2]/button[2]"));
		dateClosebtn.click();
		WebElement timeOfarrivals = driver.findElement(timeofarrival);
		timeOfarrivals.click();
		WebElement outsideAuthContct = driver.findElement(outsideauthcontct);
		outsideAuthContct.click();
		WebElement detectedBy = driver.findElement(detectedby);
		detectedBy.click();
		WebElement evacuationTogl = driver.findElement(evacuation);
		evacuationTogl.click();
		WebElement shelterInSpace = driver.findElement(shelterinspace);
		shelterInSpace.click();
		WebElement initiateDuresActv = driver.findElement(initiateduresactv);
		initiateDuresActv.click();
		WebElement createCasebutton = driver.findElement(createcasebutton);
		createCasebutton.click();
		components();

	}

}

/*
 * WebElement notesclearField= driver.findElement(By.xpath(
 * "//button[@class='mlg-cancel-button' and contains (text(),'Clear Fields')]"
 * )); notesclearField.click(); WebElement notescancel=
 * driver.findElement(By.xpath(
 * "//a[@class='mlg-cancel-button' and contains (text(),'Cancel')]"));
 * notescancel.click(); ;
 */
